"""Smoke tests: model loads and scores, and the Streamlit app renders without errors."""
from pathlib import Path

import joblib
import pandas as pd
from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parents[1]
APP = str(ROOT / "app.py")
MODEL = ROOT / "models" / "fraud_detection_model.pkl"
SAMPLE = ROOT / "data" / "sample_transactions.csv"
FEATURES = ["step", "amount", "type_CASH_OUT", "type_DEBIT", "type_PAYMENT", "type_TRANSFER"]


def test_model_scores_sample_data():
    model = joblib.load(MODEL)
    X = pd.read_csv(SAMPLE)[FEATURES]
    probs = model.predict_proba(X)[:, 1]
    assert len(probs) == len(X)
    assert ((probs >= 0) & (probs <= 1)).all()


def test_app_overview_renders():
    at = AppTest.from_file(APP, default_timeout=60).run()
    assert not at.exception


def test_single_transaction_flow():
    at = AppTest.from_file(APP, default_timeout=60).run()
    at.button(key="nav_🔍 Fraud Detection").click().run()
    assert not at.exception
    analyze = [b for b in at.button if "Analyze" in b.label][0]
    analyze.click().run()
    assert not at.exception
    assert len(at.session_state["history"]) == 1
    assert at.session_state["history"][0]["verdict"] in {"Fraud", "Legit"}
