"""
FraudGuard — Real-Time Fraud & Orders Analytics Dashboard
--------------------------------------------------------------
Run with:   streamlit run app.py
Install:    pip install streamlit plotly pandas numpy joblib scikit-learn

SETUP:
1. The trained model lives in models/fraud_detection_model.pkl (path is
   resolved relative to this file, so it works from any working directory).
2. FEATURE_COLUMNS below already matches the PaySim-based model
   (step, amount, one-hot transaction type) — update MODEL_METRICS
   with your own classification_report numbers if you retrain.
3. On the Overview page, generate_demo_data() can be swapped for your
   real orders CSV later.
"""

import streamlit as st
import pandas as pd
import numpy as np
import pickle
import joblib
import time
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime
from pathlib import Path

# ==================================================================
# CONFIG — edit to match your model
# ==================================================================
MODEL_PATH = str(Path(__file__).resolve().parent / "models" / "fraud_detection_model.pkl")
SCALER_PATH = None
FEATURE_COLUMNS = ["step", "amount", "type_CASH_OUT", "type_DEBIT", "type_PAYMENT", "type_TRANSFER"]

# Your actual classification_report numbers — update these after retraining
MODEL_METRICS = {
    "accuracy": 0.9201,
    "roc_auc": 0.8843,
    "precision_fraud": 0.6757,
    "recall_fraud": 0.8344,
    "f1_fraud": 0.7467,
    "precision_legit": 0.9717,
    "recall_legit": 0.9342,
    "f1_legit": 0.9526,
    "support_fraud": 1643,
    "support_legit": 10000,
    "confusion_matrix": [[9342, 658], [272, 1371]],  # [[TN, FP], [FN, TP]] approx from your report
}

st.set_page_config(page_title="FraudGuard Analytics", page_icon="🛡️", layout="wide")

# ==================================================================
# GLOBAL STYLE — neon glass theme, NO grey text anywhere
# ==================================================================
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap');
html, body, [class*="css"] { font-family: 'Poppins', sans-serif; }

.stApp {
    background:
        radial-gradient(circle at 8% 8%, rgba(123,47,247,0.25) 0%, transparent 35%),
        radial-gradient(circle at 92% 15%, rgba(75,216,255,0.18) 0%, transparent 35%),
        radial-gradient(circle at 50% 100%, rgba(255,75,216,0.12) 0%, transparent 40%),
        linear-gradient(180deg, #07060f 0%, #0a0817 60%, #060510 100%);
    color: #f1f1fb;
}
section[data-testid="stSidebar"] {
    background: linear-gradient(180deg, #150c2e 0%, #0a0817 100%);
    border-right: 1px solid rgba(255,75,216,0.15);
}
[data-testid="stHeader"] { background: transparent; }

/* ---- kill grey text everywhere in the sidebar ---- */
section[data-testid="stSidebar"] p,
section[data-testid="stSidebar"] span,
section[data-testid="stSidebar"] label,
section[data-testid="stSidebar"] .stMarkdown,
section[data-testid="stSidebar"] .stCaption {
    color: #d9cdfb !important;
}
section[data-testid="stSidebar"] .stSlider label { color: #ff9de8 !important; font-weight: 700 !important; }
section[data-testid="stSidebar"] hr { border-color: rgba(255,75,216,0.25) !important; }

.brand {
    font-size: 1.6rem; font-weight: 800;
    background: linear-gradient(90deg,#ff4bd8,#7b2ff7,#4bd8ff);
    -webkit-background-clip: text; -webkit-text-fill-color: transparent;
    margin-bottom: 0;
}
.sidebar-caption {
    color: #a99be8 !important; font-size: 0.85rem; font-weight: 600;
}
.badge {
    display: inline-block; padding: 4px 10px; border-radius: 20px; font-size: 0.75rem;
    font-weight: 700; background: linear-gradient(90deg,#4bd8ff,#7b2ff7); color: #fff;
}
.page-title {
    font-size: 2.1rem; font-weight: 800; color: #ffffff; margin-bottom: 2px;
    text-shadow: 0 0 22px rgba(123,47,247,0.45);
}
.page-sub { color: #b6b0e6; margin-top: 0; font-size: 0.95rem; }

.glass {
    position: relative; background: rgba(255,255,255,0.045);
    border: 1px solid rgba(255,255,255,0.10);
    backdrop-filter: blur(16px); -webkit-backdrop-filter: blur(16px);
    border-radius: 18px; padding: 18px 20px;
    box-shadow: 0 4px 24px rgba(0,0,0,0.35);
    transition: transform 0.25s ease, box-shadow 0.25s ease, border 0.25s ease;
}
.glass:hover { transform: translateY(-5px) scale(1.012); }

.kpi { border-left: 4px solid var(--accent, #7b2ff7); }
.kpi:hover { box-shadow: 0 0 28px var(--accent, #7b2ff7); border-color: var(--accent, #7b2ff7); }
.kpi-label { color: #b0aad8; font-size: 0.78rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.6px; }
.kpi-value { font-size: 1.85rem; font-weight: 800; color: #ffffff; margin-top: 2px; }
.kpi-icon { font-size: 1.4rem; opacity: 0.9; }

.fraud-card {
    background: linear-gradient(135deg, rgba(255,60,60,0.22), rgba(15,10,25,0.7));
    border: 1px solid #ff4b4b; border-radius: 20px; padding: 26px; text-align:center;
    box-shadow: 0 0 40px rgba(255,60,60,0.35); animation: pulseRed 1.8s infinite;
}
@keyframes pulseRed { 0%,100% { box-shadow: 0 0 25px rgba(255,60,60,0.25); } 50% { box-shadow: 0 0 45px rgba(255,60,60,0.55); } }
.legit-card {
    background: linear-gradient(135deg, rgba(33,197,93,0.20), rgba(10,20,20,0.7));
    border: 1px solid #21c55d; border-radius: 20px; padding: 26px; text-align:center;
    box-shadow: 0 0 35px rgba(33,197,93,0.30);
}

.alert-card {
    background: linear-gradient(135deg, rgba(255,75,75,0.14), rgba(123,47,247,0.10));
    border: 1px solid rgba(255,75,75,0.5); border-radius: 14px; padding: 14px 16px;
    transition: transform 0.2s ease, box-shadow 0.2s ease;
}
.alert-card:hover { transform: scale(1.04); box-shadow: 0 0 22px rgba(255,75,75,0.5); }
.alert-title { color: #ff9a9a; font-weight: 700; font-size: 0.92rem; }
.alert-sub { color: #d6d2f0; font-size: 0.8rem; }

.ticker-wrap {
    overflow: hidden; white-space: nowrap; border: 1px solid rgba(255,75,216,0.35);
    border-radius: 12px; background: rgba(255,255,255,0.04); padding: 8px 0; margin-bottom: 14px;
}
.ticker { display: inline-block; padding-left: 100%; animation: scroll-left 22s linear infinite; color: #ffd7f5; font-weight: 600; }
@keyframes scroll-left { 0% { transform: translateX(0); } 100% { transform: translateX(-100%); } }

div.stButton > button {
    background: linear-gradient(90deg, #ff4bd8, #7b2ff7); color: white; border: none;
    border-radius: 10px; padding: 0.6em 1.4em; font-weight: 700; width: 100%;
    box-shadow: 0 4px 18px rgba(123,47,247,0.45); transition: box-shadow 0.2s ease;
}
div.stButton > button:hover { box-shadow: 0 6px 30px rgba(255,75,216,0.6); }

section[data-testid="stSidebar"] div.stButton > button {
    text-align: left; justify-content: flex-start; font-size: 0.95rem; margin-bottom: 6px;
}
section[data-testid="stSidebar"] button[data-testid="stBaseButton-secondary"] {
    background: rgba(123,47,247,0.14) !important; border: 1px solid rgba(123,47,247,0.6) !important;
    color: #e6defe !important; box-shadow: none !important;
}
section[data-testid="stSidebar"] button[data-testid="stBaseButton-secondary"]:hover {
    border-color: #ff4bd8 !important; color: #ffffff !important;
    box-shadow: 0 0 18px rgba(255,75,216,0.45) !important; background: rgba(255,75,216,0.16) !important;
}
section[data-testid="stSidebar"] button[data-testid="stBaseButton-primary"] {
    background: linear-gradient(90deg, #ff4bd8, #7b2ff7) !important; border: none !important;
    color: #ffffff !important; box-shadow: 0 0 24px rgba(255,75,216,0.55) !important;
}

.section-head { font-size: 1.15rem; font-weight: 700; color: #fff; margin-bottom: 8px;
                border-left: 3px solid #7b2ff7; padding-left: 10px; }
hr { border-color: rgba(255,255,255,0.08); }
[data-testid="stMetricValue"] { color: #fff; }
[data-testid="stMetricLabel"] { color: #b6b0e6 !important; }
</style>
""", unsafe_allow_html=True)


# ==================================================================
# DEMO DATA (Overview page) — swap for real orders CSV later
# ==================================================================
@st.cache_data
def generate_demo_data(seed=42, n_orders=1840, n_customers=260):
    rng = np.random.default_rng(seed)
    days = list(range(1, 32))
    trend_df = pd.DataFrame({"Day": days, "Orders": rng.integers(40, 80, size=len(days))})
    cancel_reasons = pd.DataFrame({
        "reason": ["Out of Stock", "Payment Failed", "Customer Cancelled", "Address Issue", "Other"],
        "count": rng.integers(120, 1300, size=5)})
    return_reasons = pd.DataFrame({
        "reason": ["Quality Issue", "Not as described", "Changed my mind", "Size/Fit Issue", "Damaged product"],
        "count": rng.integers(100, 1300, size=5)})
    customer_ids = [f"CUST{10000+i}" for i in range(n_customers)]
    fraud_scores = rng.integers(5, 300, size=n_customers)
    risk_level = np.where(fraud_scores > 150, "High", np.where(fraud_scores > 70, "Medium", "Low"))
    cust_df = pd.DataFrame({
        "customer_id": customer_ids, "total_orders": rng.integers(1, 15, size=n_customers),
        "return_requests": rng.integers(0, 8, size=n_customers), "refund_amount": rng.integers(0, 25000, size=n_customers),
        "fraud_score": fraud_scores, "risk_level": risk_level})
    cust_df["return_rate"] = (cust_df["return_requests"] / cust_df["total_orders"]).round(2) * 100
    fraud_trend = pd.DataFrame({
        "Day": np.tile(range(1, 32), 2), "risk_level": ["High"] * 31 + ["Medium"] * 31,
        "fraud_score_sum": np.concatenate([rng.integers(400, 2200, size=31), rng.integers(300, 1900, size=31)])})
    kpis = {"total_orders": n_orders, "completed": int(n_orders * 0.34), "cancelled": int(n_orders * 0.32),
            "return_requests": int(n_orders * 0.34), "return_rate": 33.91, "total_gmv": 4_754_000,
            "total_refunds": 1_660_000, "potential_fraud": int((cust_df["risk_level"] == "High").sum() + 100)}
    return trend_df, cancel_reasons, return_reasons, cust_df, fraud_trend, kpis


trend_df, cancel_reasons, return_reasons, cust_df, fraud_trend, kpis = generate_demo_data()

if "history" not in st.session_state:
    st.session_state.history = []
if "sim_running" not in st.session_state:
    st.session_state.sim_running = False
if "sim_log" not in st.session_state:
    st.session_state.sim_log = []


# ==================================================================
# MODEL LOADING
# ==================================================================
@st.cache_resource
def load_model():
    try:
        with open(MODEL_PATH, "rb") as f:
            return pickle.load(f)
    except Exception:
        return joblib.load(MODEL_PATH)


@st.cache_resource
def load_scaler():
    if SCALER_PATH is None:
        return None
    try:
        with open(SCALER_PATH, "rb") as f:
            return pickle.load(f)
    except Exception:
        return joblib.load(SCALER_PATH)


model, scaler, model_error = None, None, None
try:
    model = load_model()
    scaler = load_scaler()
except Exception as e:
    model_error = str(e)


def preprocess(df):
    df = df.copy()[FEATURE_COLUMNS]
    if scaler is not None:
        df[FEATURE_COLUMNS] = scaler.transform(df[FEATURE_COLUMNS])
    return df


def predict(df, threshold):
    X = preprocess(df)
    try:
        probs = model.predict_proba(X)[:, 1]
    except Exception:
        probs = model.predict(X).astype(float)
    preds = (probs >= threshold).astype(int)
    return preds, probs


def risk_factor_breakdown(input_row: dict):
    vals = np.array([input_row[c] for c in FEATURE_COLUMNS], dtype=float)
    weights = None
    try:
        if hasattr(model, "feature_importances_"):
            weights = np.array(model.feature_importances_, dtype=float)
        elif hasattr(model, "coef_"):
            weights = np.array(model.coef_).flatten().astype(float)
    except Exception:
        weights = None
    if weights is None or len(weights) != len(vals):
        contrib = np.abs(vals) / (np.abs(vals).sum() + 1e-9)
    else:
        raw = weights * (vals / (np.abs(vals).max() + 1e-9))
        contrib = np.abs(raw) / (np.abs(raw).sum() + 1e-9)
    return pd.DataFrame({"feature": FEATURE_COLUMNS, "influence": contrib}).sort_values("influence", ascending=True)


def random_transaction(rng):
    txn_type = rng.choice(["CASH_IN", "CASH_OUT", "DEBIT", "PAYMENT", "TRANSFER"], p=[0.22, 0.32, 0.06, 0.32, 0.08])
    amount = float(rng.lognormal(mean=8.5, sigma=1.3))
    step = int(rng.integers(1, 743))
    row = {"step": step, "amount": round(amount, 2),
           "type_CASH_OUT": 1 if txn_type == "CASH_OUT" else 0,
           "type_DEBIT": 1 if txn_type == "DEBIT" else 0,
           "type_PAYMENT": 1 if txn_type == "PAYMENT" else 0,
           "type_TRANSFER": 1 if txn_type == "TRANSFER" else 0}
    return row, txn_type


# ==================================================================
# SIDEBAR NAV
# ==================================================================
with st.sidebar:
    st.markdown('<p class="brand">🛡️ FraudGuard</p>', unsafe_allow_html=True)
    st.markdown('<span class="sidebar-caption">Real-Time Fraud Intelligence Suite</span>', unsafe_allow_html=True)
    st.write("")

    nav_items = ["📊 Overview", "🔍 Fraud Detection", "🔴 Live Simulation", "📈 Model Performance", "🕒 Session History"]
    if "page" not in st.session_state:
        st.session_state.page = nav_items[0]
    for item in nav_items:
        is_active = st.session_state.page == item
        if st.button(item, key=f"nav_{item}", use_container_width=True,
                     type="primary" if is_active else "secondary"):
            st.session_state.page = item
            st.session_state.sim_running = False
            st.rerun()
    page = st.session_state.page
    st.divider()

    if model is not None:
        st.markdown('<span class="badge">● MODEL ONLINE</span>', unsafe_allow_html=True)
    else:
        st.error("Model not loaded")
        st.caption(str(model_error))

    threshold = st.slider("⚙️ Fraud alert threshold", 0.0, 1.0, 0.5, 0.05)
    st.divider()
    st.markdown(f'<span class="sidebar-caption">🕒 Session checks: {len(st.session_state.history)}</span>', unsafe_allow_html=True)
    st.markdown(f'<span class="sidebar-caption">📡 Simulated txns: {len(st.session_state.sim_log)}</span>', unsafe_allow_html=True)


def kpi_card(col, icon, label, value, color):
    with col:
        st.markdown(f"""<div class="glass kpi" style="--accent:{color}">
            <div class="kpi-icon">{icon}</div><div class="kpi-label">{label}</div>
            <div class="kpi-value">{value}</div></div>""", unsafe_allow_html=True)


def live_ticker(items):
    text = "&nbsp;&nbsp;🔺&nbsp;&nbsp;".join(items)
    st.markdown(f'<div class="ticker-wrap"><div class="ticker">{text}</div></div>', unsafe_allow_html=True)


# ==================================================================
# PAGE 1: OVERVIEW
# ==================================================================
if page == "📊 Overview":
    st.markdown('<p class="page-title">📊 Orders & Fraud Analytics</p>', unsafe_allow_html=True)
    st.markdown('<p class="page-sub">Live snapshot of orders, returns, and fraud risk</p>', unsafe_allow_html=True)

    live_ticker([
        f"⚠️ {kpis['potential_fraud']} potential fraud cases this month",
        f"📉 Return rate at {kpis['return_rate']}%",
        f"💸 ₹{kpis['total_refunds']/1e6:.2f}M refunded",
        f"🛍️ {kpis['total_orders']:,} total orders tracked",
    ])

    c1, c2, c3, c4, c5, c6, c7 = st.columns(7)
    kpi_card(c1, "🛍️", "Total Orders", f"{kpis['total_orders']:,}", "#4bd8ff")
    kpi_card(c2, "✅", "Completed", f"{kpis['completed']:,}", "#21c55d")
    kpi_card(c3, "❌", "Cancelled", f"{kpis['cancelled']:,}", "#ff4b4b")
    kpi_card(c4, "🔁", "Return Requests", f"{kpis['return_requests']:,}", "#e8c34a")
    kpi_card(c5, "📉", "Return Rate", f"{kpis['return_rate']}%", "#ff9d4b")
    kpi_card(c6, "💰", "Total GMV", f"₹{kpis['total_gmv']/1e6:.2f}M", "#7b2ff7")
    kpi_card(c7, "💸", "Total Refunds", f"₹{kpis['total_refunds']/1e6:.2f}M", "#ff4bd8")

    st.write("")
    left_alert, main_area = st.columns([0.22, 0.78])
    with left_alert:
        st.markdown(f"""<div class="glass" style="text-align:center; border:1px solid rgba(255,75,75,0.55); box-shadow:0 0 26px rgba(255,75,75,0.25);">
            <div style="color:#ff9a9a; font-weight:700;">⚠️ Potential Fraud</div>
            <div style="font-size:2.5rem; font-weight:800; color:#ff4b4b;">{kpis['potential_fraud']}</div></div>""", unsafe_allow_html=True)
        with st.expander("🔎 Search high risk customers"):
            q = st.text_input("Customer ID contains...", "")
            hi = cust_df[cust_df["risk_level"] == "High"].sort_values("fraud_score", ascending=False)
            if q:
                hi = hi[hi["customer_id"].str.contains(q, case=False)]
            st.dataframe(hi.head(15), use_container_width=True, hide_index=True)

    with main_area:
        r1c1, r1c2, r1c3 = st.columns(3)
        with r1c1:
            st.markdown('<div class="glass">', unsafe_allow_html=True)
            fig = px.line(trend_df, x="Day", y="Orders", markers=True, title="Orders Trend")
            fig.update_traces(line_color="#4bd8ff")
            fig.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                               font={"color": "#eaeaf5"}, height=280, margin=dict(t=40, b=10, l=10, r=10))
            st.plotly_chart(fig, use_container_width=True)
            st.markdown('</div>', unsafe_allow_html=True)
        with r1c2:
            st.markdown('<div class="glass">', unsafe_allow_html=True)
            fig = px.pie(cancel_reasons, names="reason", values="count", hole=0.55, title="Cancellation Reasons",
                         color_discrete_sequence=px.colors.sequential.Plasma)
            fig.update_layout(paper_bgcolor="rgba(0,0,0,0)", font={"color": "#eaeaf5"}, height=280, margin=dict(t=40, b=10, l=10, r=10))
            st.plotly_chart(fig, use_container_width=True)
            st.markdown('</div>', unsafe_allow_html=True)
        with r1c3:
            st.markdown('<div class="glass">', unsafe_allow_html=True)
            fig = px.pie(return_reasons, names="reason", values="count", hole=0.55, title="Return Reasons",
                         color_discrete_sequence=px.colors.sequential.Magma)
            fig.update_layout(paper_bgcolor="rgba(0,0,0,0)", font={"color": "#eaeaf5"}, height=280, margin=dict(t=40, b=10, l=10, r=10))
            st.plotly_chart(fig, use_container_width=True)
            st.markdown('</div>', unsafe_allow_html=True)

    st.write("")
    r2c1, r2c2 = st.columns([1.3, 1])
    with r2c1:
        st.markdown('<div class="glass">', unsafe_allow_html=True)
        st.markdown('<div class="section-head">High Risk Customers (Potential Frauds)</div>', unsafe_allow_html=True)
        st.dataframe(cust_df.sort_values("fraud_score", ascending=False).head(12)[
            ["customer_id", "total_orders", "return_requests", "return_rate", "refund_amount", "fraud_score", "risk_level"]],
            use_container_width=True, hide_index=True)
        st.markdown('</div>', unsafe_allow_html=True)
    with r2c2:
        st.markdown('<div class="glass">', unsafe_allow_html=True)
        risk_counts = cust_df["risk_level"].value_counts().reset_index()
        risk_counts.columns = ["risk_level", "count"]
        fig = px.pie(risk_counts, names="risk_level", values="count", hole=0.55,
                     title=f"Fraud Score Distribution ({len(cust_df)} customers)", color="risk_level",
                     color_discrete_map={"High": "#ff4b4b", "Medium": "#7b2ff7", "Low": "#4bd8ff"})
        fig.update_layout(paper_bgcolor="rgba(0,0,0,0)", font={"color": "#eaeaf5"}, height=320, margin=dict(t=40, b=10, l=10, r=10))
        st.plotly_chart(fig, use_container_width=True)
        st.markdown('</div>', unsafe_allow_html=True)

    st.write("")
    st.markdown('<div class="glass">', unsafe_allow_html=True)
    st.markdown('<div class="section-head">Fraud Score Trend</div>', unsafe_allow_html=True)
    fig = px.line(fraud_trend, x="Day", y="fraud_score_sum", color="risk_level", markers=True,
                   color_discrete_map={"High": "#4bd8ff", "Medium": "#e8c34a"})
    fig.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                       font={"color": "#eaeaf5"}, height=280, margin=dict(t=20, b=10, l=10, r=10))
    st.plotly_chart(fig, use_container_width=True)
    st.markdown('</div>', unsafe_allow_html=True)

    st.write("")
    st.markdown('<div class="section-head">🔔 Recent Alerts</div>', unsafe_allow_html=True)
    alerts = [
        ("High Return Rate Detected", f"Customer ID: {cust_df.iloc[0]['customer_id']}"),
        ("Multiple Returns For Same Product", "Product ID: SKU-2291"),
        ("High Refund Amount", f"₹{int(cust_df['refund_amount'].max()):,}"),
        ("COD Order Pattern Suspicious", f"Customer ID: {cust_df.iloc[1]['customer_id']}"),
        ("Potential Fraud Detected", f"Fraud Score: {int(cust_df['fraud_score'].max())}"),
    ]
    acols = st.columns(len(alerts))
    for col, (title, sub) in zip(acols, alerts):
        with col:
            st.markdown(f'<div class="alert-card"><div class="alert-title">⚠️ {title}</div><div class="alert-sub">{sub}</div></div>', unsafe_allow_html=True)


# ==================================================================
# PAGE 2: FRAUD DETECTION
# ==================================================================
elif page == "🔍 Fraud Detection":
    st.markdown('<p class="page-title">🔍 Fraud Detection</p>', unsafe_allow_html=True)
    st.markdown('<p class="page-sub">Score a transaction and see exactly why it was flagged</p>', unsafe_allow_html=True)

    tab1, tab2 = st.tabs(["🔍 Single Transaction", "📁 Batch Upload"])

    with tab1:
        left, right = st.columns([1.1, 1])
        with left:
            st.markdown('<div class="glass">', unsafe_allow_html=True)
            c1, c2 = st.columns(2)
            with c1:
                step = st.number_input("⏱️ Step (time unit)", min_value=0, value=100)
                amount = st.number_input("💰 Amount", min_value=0.0, value=1000.0)
            with c2:
                txn_type = st.selectbox("Transaction Type", ["CASH_IN", "CASH_OUT", "DEBIT", "PAYMENT", "TRANSFER"])
                st.caption("CASH_IN is the baseline category (all flags = 0)")
            run = st.button("🚀 Analyze Transaction", type="primary", use_container_width=True)
            st.markdown('</div>', unsafe_allow_html=True)

        with right:
            placeholder = st.empty()
            if not run:
                placeholder.info("Fill in details and click **Analyze Transaction**.")

        if run:
            if model is None:
                st.error("Model not loaded — fix MODEL_PATH in the code.")
            else:
                row = {"step": step, "amount": amount,
                       "type_CASH_OUT": 1 if txn_type == "CASH_OUT" else 0,
                       "type_DEBIT": 1 if txn_type == "DEBIT" else 0,
                       "type_PAYMENT": 1 if txn_type == "PAYMENT" else 0,
                       "type_TRANSFER": 1 if txn_type == "TRANSFER" else 0}
                input_df = pd.DataFrame([row])
                pred, prob = predict(input_df, threshold)
                pred, prob = pred[0], prob[0]

                st.session_state.history.append({
                    "time": datetime.now().strftime("%H:%M:%S"), "step": step, "amount": amount, "type": txn_type,
                    "risk_score": round(float(prob), 4), "verdict": "Fraud" if pred == 1 else "Legit"})

                with right:
                    color = "#ff4b4b" if prob >= threshold else "#21c55d"
                    fig = go.Figure(go.Indicator(mode="gauge+number", value=prob * 100, number={"suffix": "%"},
                        gauge={"axis": {"range": [0, 100]}, "bar": {"color": color},
                               "threshold": {"line": {"color": "white", "width": 3}, "thickness": 0.8, "value": threshold*100}}))
                    fig.update_layout(height=250, margin=dict(t=20, b=10, l=20, r=20), paper_bgcolor="rgba(0,0,0,0)", font={"color": "white"})
                    placeholder.plotly_chart(fig, use_container_width=True)
                    if pred == 1:
                        st.markdown(f'<div class="fraud-card"><h3>⚠️ FRAUD ALERT</h3><p>Risk: <b>{prob:.1%}</b></p></div>', unsafe_allow_html=True)
                    else:
                        st.markdown(f'<div class="legit-card"><h3>✅ Legitimate</h3><p>Risk: <b>{prob:.1%}</b></p></div>', unsafe_allow_html=True)
                        st.balloons()

                st.write("")
                st.markdown('<div class="glass">', unsafe_allow_html=True)
                st.markdown('<div class="section-head">🧠 Why this score? — Risk Factor Breakdown</div>', unsafe_allow_html=True)
                try:
                    breakdown = risk_factor_breakdown(row)
                    fig2 = px.bar(breakdown, x="influence", y="feature", orientation="h", color="influence", color_continuous_scale="Plasma")
                    fig2.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)", font={"color": "#eaeaf5"},
                                        height=260, margin=dict(t=10, b=10, l=10, r=10), coloraxis_showscale=False)
                    st.plotly_chart(fig2, use_container_width=True)
                    st.caption(f"💡 **{breakdown.iloc[-1]['feature']}** had the strongest influence on this prediction.")
                except Exception:
                    st.caption("Feature-level explanation isn't available for this model type.")
                st.markdown('</div>', unsafe_allow_html=True)

    with tab2:
        st.caption(f"Required columns: {', '.join(FEATURE_COLUMNS)}")
        uploaded_file = st.file_uploader("Upload CSV", type="csv")
        if uploaded_file is not None:
            data = pd.read_csv(uploaded_file)
            st.dataframe(data.head(), use_container_width=True)
            missing = [c for c in FEATURE_COLUMNS if c not in data.columns]
            if missing:
                st.error(f"Missing columns: {missing}")
            elif model is None:
                st.error("Model not loaded.")
            elif st.button("🚀 Run Batch Scoring", type="primary"):
                preds, probs = predict(data, threshold)
                result = data.copy()
                result["fraud_probability"] = probs
                result["prediction"] = np.where(preds == 1, "Fraud", "Legit")
                m1, m2, m3 = st.columns(3)
                m1.metric("Total", len(result)); m2.metric("🚨 Fraud", int((preds==1).sum())); m3.metric("✅ Legit", int((preds==0).sum()))
                fig = px.histogram(result, x="fraud_probability", nbins=30, title="Risk Score Distribution", color_discrete_sequence=["#7b2ff7"])
                fig.add_vline(x=threshold, line_dash="dash", line_color="#ff4b4b")
                fig.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)", font={"color": "#eaeaf5"})
                st.plotly_chart(fig, use_container_width=True)
                st.dataframe(result, use_container_width=True)
                st.download_button("⬇️ Download Results", result.to_csv(index=False).encode(), "fraud_predictions.csv", "text/csv")


# ==================================================================
# PAGE 3: LIVE SIMULATION (new — mimics real-time fraud monitoring)
# ==================================================================
elif page == "🔴 Live Simulation":
    st.markdown('<p class="page-title">🔴 Live Transaction Simulation</p>', unsafe_allow_html=True)
    st.markdown('<p class="page-sub">Simulates a real-time transaction stream being scored as it arrives</p>', unsafe_allow_html=True)

    if model is None:
        st.error("Model not loaded — fix MODEL_PATH in the code.")
    else:
        c1, c2, c3 = st.columns([1, 1, 2])
        with c1:
            n_txns = st.slider("Transactions to simulate", 5, 50, 15)
        with c2:
            speed = st.slider("Speed (sec/txn)", 0.1, 1.5, 0.4)
        with c3:
            st.write("")
            start = st.button("▶️ Start Live Stream", type="primary", use_container_width=True)

        feed_area = st.empty()
        metrics_area = st.empty()

        if start:
            rng = np.random.default_rng()
            batch_log = []
            for i in range(n_txns):
                row, txn_type = random_transaction(rng)
                pred, prob = predict(pd.DataFrame([row]), threshold)
                pred, prob = pred[0], prob[0]
                entry = {"time": datetime.now().strftime("%H:%M:%S"), "step": row["step"],
                         "amount": round(row["amount"], 2), "type": txn_type,
                         "risk_score": round(float(prob), 4), "verdict": "🚨 Fraud" if pred == 1 else "✅ Legit"}
                batch_log.insert(0, entry)
                st.session_state.sim_log.append(entry)

                with feed_area.container():
                    st.markdown('<div class="glass">', unsafe_allow_html=True)
                    st.markdown('<div class="section-head">📡 Live Feed</div>', unsafe_allow_html=True)
                    st.dataframe(pd.DataFrame(batch_log), use_container_width=True, hide_index=True)
                    st.markdown('</div>', unsafe_allow_html=True)

                fraud_so_far = sum(1 for e in batch_log if "Fraud" in e["verdict"])
                with metrics_area.container():
                    m1, m2, m3 = st.columns(3)
                    m1.metric("Processed", i + 1)
                    m2.metric("🚨 Flagged Fraud", fraud_so_far)
                    m3.metric("Live Fraud Rate", f"{fraud_so_far/(i+1):.1%}")

                time.sleep(speed)
            st.success("Stream complete. Flagged transactions are logged — check Session History or download below.")
            st.download_button("⬇️ Download Simulation Log", pd.DataFrame(batch_log).to_csv(index=False).encode(),
                                "simulation_log.csv", "text/csv")
        else:
            feed_area.info("Click **Start Live Stream** to simulate incoming transactions being scored in real time.")


# ==================================================================
# PAGE 4: MODEL PERFORMANCE (new — for review/demo credibility)
# ==================================================================
elif page == "📈 Model Performance":
    st.markdown('<p class="page-title">📈 Model Performance</p>', unsafe_allow_html=True)
    st.markdown('<p class="page-sub">RandomForestClassifier trained on PaySim behavioral features</p>', unsafe_allow_html=True)

    m = MODEL_METRICS
    c1, c2, c3, c4 = st.columns(4)
    kpi_card(c1, "🎯", "Accuracy", f"{m['accuracy']:.2%}", "#4bd8ff")
    kpi_card(c2, "📐", "ROC-AUC", f"{m['roc_auc']:.4f}", "#7b2ff7")
    kpi_card(c3, "🚨", "Fraud F1-Score", f"{m['f1_fraud']:.4f}", "#ff4b4b")
    kpi_card(c4, "✅", "Legit F1-Score", f"{m['f1_legit']:.4f}", "#21c55d")

    st.write("")
    r1, r2 = st.columns(2)
    with r1:
        st.markdown('<div class="glass">', unsafe_allow_html=True)
        st.markdown('<div class="section-head">Precision vs Recall by Class</div>', unsafe_allow_html=True)
        pr_df = pd.DataFrame({
            "Class": ["Legit", "Legit", "Fraud", "Fraud"],
            "Metric": ["Precision", "Recall", "Precision", "Recall"],
            "Score": [m['precision_legit'], m['recall_legit'], m['precision_fraud'], m['recall_fraud']]})
        fig = px.bar(pr_df, x="Class", y="Score", color="Metric", barmode="group",
                     color_discrete_map={"Precision": "#4bd8ff", "Recall": "#ff4bd8"})
        fig.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)", font={"color": "#eaeaf5"},
                           height=320, margin=dict(t=20, b=10, l=10, r=10))
        st.plotly_chart(fig, use_container_width=True)
        st.markdown('</div>', unsafe_allow_html=True)

    with r2:
        st.markdown('<div class="glass">', unsafe_allow_html=True)
        st.markdown('<div class="section-head">Confusion Matrix</div>', unsafe_allow_html=True)
        cm = np.array(m["confusion_matrix"])
        fig = px.imshow(cm, text_auto=True, color_continuous_scale="Purples",
                         x=["Pred Legit", "Pred Fraud"], y=["Actual Legit", "Actual Fraud"])
        fig.update_layout(paper_bgcolor="rgba(0,0,0,0)", font={"color": "#eaeaf5"},
                           height=320, margin=dict(t=20, b=10, l=10, r=10), coloraxis_showscale=False)
        st.plotly_chart(fig, use_container_width=True)
        st.markdown('</div>', unsafe_allow_html=True)

    st.write("")
    st.markdown('<div class="glass">', unsafe_allow_html=True)
    st.markdown('<div class="section-head">📋 Full Classification Report</div>', unsafe_allow_html=True)
    report_df = pd.DataFrame({
        "Class": ["Legit (0)", "Fraud (1)"],
        "Precision": [m['precision_legit'], m['precision_fraud']],
        "Recall": [m['recall_legit'], m['recall_fraud']],
        "F1-Score": [m['f1_legit'], m['f1_fraud']],
        "Support": [m['support_legit'], m['support_fraud']]})
    st.dataframe(report_df, use_container_width=True, hide_index=True)
    st.caption("💡 Fraud F1 is lower than Legit F1 by design — fraud is the harder minority class. "
               "Balance-based features were excluded during training to avoid data leakage.")
    st.markdown('</div>', unsafe_allow_html=True)

    if model is not None and hasattr(model, "feature_importances_"):
        st.write("")
        st.markdown('<div class="glass">', unsafe_allow_html=True)
        st.markdown('<div class="section-head">Feature Importance</div>', unsafe_allow_html=True)
        imp_df = pd.DataFrame({"feature": FEATURE_COLUMNS, "importance": model.feature_importances_}).sort_values("importance")
        fig = px.bar(imp_df, x="importance", y="feature", orientation="h", color="importance", color_continuous_scale="Plasma")
        fig.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)", font={"color": "#eaeaf5"},
                           height=280, margin=dict(t=10, b=10, l=10, r=10), coloraxis_showscale=False)
        st.plotly_chart(fig, use_container_width=True)
        st.markdown('</div>', unsafe_allow_html=True)


# ==================================================================
# PAGE 5: SESSION HISTORY
# ==================================================================
else:
    st.markdown('<p class="page-title">🕒 Session History</p>', unsafe_allow_html=True)
    st.markdown('<p class="page-sub">Every transaction you\'ve checked this session</p>', unsafe_allow_html=True)

    if not st.session_state.history:
        st.info("No transactions checked yet. Go to **Fraud Detection → Single Transaction** and analyze one.")
    else:
        hist_df = pd.DataFrame(st.session_state.history)
        c1, c2, c3 = st.columns(3)
        c1.metric("Total Checked", len(hist_df))
        c2.metric("🚨 Flagged Fraud", int((hist_df["verdict"] == "Fraud").sum()))
        c3.metric("Avg Risk Score", f"{hist_df['risk_score'].mean():.1%}")

        st.markdown('<div class="glass">', unsafe_allow_html=True)
        st.markdown('<div class="section-head">Risk Score Over Time</div>', unsafe_allow_html=True)
        fig = px.line(hist_df.reset_index(), x="index", y="risk_score", markers=True, color_discrete_sequence=["#ff4bd8"])
        fig.add_hline(y=threshold, line_dash="dash", line_color="#4bd8ff")
        fig.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)", font={"color": "#eaeaf5"},
                           xaxis_title="Check #", yaxis_title="Risk score")
        st.plotly_chart(fig, use_container_width=True)
        st.markdown('</div>', unsafe_allow_html=True)

        st.write("")
        st.markdown('<div class="glass">', unsafe_allow_html=True)
        st.markdown('<div class="section-head">Log</div>', unsafe_allow_html=True)
        st.dataframe(hist_df.iloc[::-1], use_container_width=True, hide_index=True)
        st.markdown('</div>', unsafe_allow_html=True)

        st.write("")
        cclear, cdown = st.columns(2)
        with cclear:
            if st.button("🗑️ Clear History"):
                st.session_state.history = []
                st.rerun()
        with cdown:
            st.download_button("⬇️ Download Session Log", hist_df.to_csv(index=False).encode(),
                                "session_history.csv", "text/csv", use_container_width=True)