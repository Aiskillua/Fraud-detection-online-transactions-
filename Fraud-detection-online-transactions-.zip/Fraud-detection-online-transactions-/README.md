# 🛡️ FraudGuard: Online Transaction Fraud Detection

[![CI](https://github.com/Aiskillua/Fraud-detection-online-transactions-/actions/workflows/ci.yml/badge.svg)](https://github.com/Aiskillua/Fraud-detection-online-transactions-/actions/workflows/ci.yml)
![Python](https://img.shields.io/badge/python-3.11%2B-blue)
![scikit-learn](https://img.shields.io/badge/scikit--learn-1.9.0-F7931E)
![Streamlit](https://img.shields.io/badge/Streamlit-dashboard-FF4B4B)
![License](https://img.shields.io/badge/license-MIT-green)

A machine-learning project that detects fraudulent online payment transactions, packaged with an interactive **Streamlit dashboard** for scoring single transactions, scoring CSV batches, simulating a live transaction stream, and reviewing model performance.

---

## Table of Contents

- [Overview](#overview)
- [Features](#features)
- [Dataset](#dataset)
- [Model](#model)
- [Results](#results)
- [Project Structure](#project-structure)
- [Getting Started](#getting-started)
- [Usage](#usage)
- [Configuration](#configuration)
- [Testing](#testing)
- [Limitations](#limitations)
- [Roadmap](#roadmap)
- [License](#license)

---

## Overview

Online payment fraud is rare but expensive: fraudulent transactions are a tiny fraction of total volume, which makes the problem highly **imbalanced**. This project trains a **Random Forest** classifier on behavioural transaction features and serves it through a dashboard where an analyst can:

1. enter a transaction and instantly see its fraud-risk score and *why* it was flagged,
2. upload a CSV of transactions and score them in bulk,
3. watch a simulated real-time stream being scored as it arrives,
4. inspect the model's metrics, confusion matrix, and feature importance.

## Features

| Page | What it does |
|---|---|
| **Overview** | Orders & fraud analytics dashboard (KPIs, trends, high-risk customers, alerts). *Uses simulated demo data; see [Limitations](#limitations).* |
| **Fraud Detection → Single Transaction** | Enter step, amount, and type; get a risk gauge, a Fraud/Legit verdict, and a risk-factor breakdown. |
| **Fraud Detection → Batch Upload** | Upload a CSV, get per-row fraud probabilities and predictions, a score histogram, and a downloadable results file. |
| **Live Simulation** | Streams randomly generated transactions through the model in real time with a live fraud-rate counter. |
| **Model Performance** | Accuracy, ROC-AUC, per-class precision/recall/F1, confusion matrix, and feature importance. |
| **Session History** | Log of every transaction checked in the session, with a risk-over-time chart and CSV export. |

A sidebar **alert threshold** slider (default `0.5`) controls the probability above which a transaction is flagged as fraud.

## Dataset

The model is trained on **PaySim**, a synthetic mobile-money transaction dataset generated from real financial logs ([Kaggle: PaySim](https://www.kaggle.com/datasets/ealaxi/paysim1)). It covers roughly 30 simulated days (hourly `step`s) and contains about 6.3 million transactions, of which only around 0.13% are fraudulent.

> The raw dataset is **not** included in this repository because of its size. Download it from Kaggle and place it in `data/raw/` (git-ignored) if you want to retrain.
>
> *Lopez-Rojas, E., Elmir, A., & Axelsson, S. (2016). PaySim: A financial mobile money simulator for fraud detection. EMSS.*

A small synthetic file, [`data/sample_transactions.csv`](data/sample_transactions.csv), is included so you can try the batch-upload feature immediately.

## Model

| | |
|---|---|
| **Algorithm** | `RandomForestClassifier` (scikit-learn) |
| **Hyperparameters** | `n_estimators=100`, `max_depth=8`, `min_samples_leaf=10`, `max_features="sqrt"`, `random_state=42` |
| **Input features** | `step`, `amount`, and one-hot encoded transaction type: `type_CASH_OUT`, `type_DEBIT`, `type_PAYMENT`, `type_TRANSFER` (`CASH_IN` is the baseline, with all flags 0) |
| **Deliberately excluded** | Account-balance columns, removed during training to avoid **data leakage** |
| **Artifact** | [`models/fraud_detection_model.pkl`](models/) (joblib format) |

**Feature importance** (from the trained model):

| Feature | Importance |
|---|---|
| `type_TRANSFER` | 0.397 |
| `amount` | 0.254 |
| `step` | 0.192 |
| `type_CASH_OUT` | 0.096 |
| `type_PAYMENT` | 0.061 |
| `type_DEBIT` | 0.001 |

## Results

Evaluated on a held-out set of 11,643 transactions (10,000 legitimate, 1,643 fraudulent):

| Class | Precision | Recall | F1-score | Support |
|---|---|---|---|---|
| Legitimate (0) | 0.9717 | 0.9342 | 0.9526 | 10,000 |
| **Fraud (1)** | **0.6757** | **0.8344** | **0.7467** | 1,643 |

**Accuracy:** 92.01% · **ROC-AUC:** 0.8843

Confusion matrix (reconstructed from the classification report):

|  | Predicted Legit | Predicted Fraud |
|---|---|---|
| **Actual Legit** | 9,342 | 658 |
| **Actual Fraud** | 272 | 1,371 |

The model prioritises **recall** on the fraud class (≈83% of fraud caught). Fraud F1 is lower than legitimate-class F1, as expected for the harder minority class.

<!--
MODEL COMPARISON: uncomment ONLY after confirming these numbers belong to the same
feature set and evaluation split as the Results table above.

### Model comparison

![Model comparison](assets/model_comparison.png)
-->

## Project Structure

```
Fraud-detection-online-transactions-/
├── app.py                         # Streamlit dashboard
├── models/
│   └── fraud_detection_model.pkl  # Trained Random Forest (joblib)
├── data/
│   └── sample_transactions.csv    # Synthetic sample for batch upload
├── assets/
│   └── model_comparison.png       # Model comparison chart
├── tests/
│   └── test_app.py                # Smoke tests (model + app pages)
├── .github/workflows/ci.yml       # GitHub Actions: runs tests on every push/PR
├── .streamlit/config.toml         # Dashboard theme
├── requirements.txt               # Runtime dependencies
├── requirements-dev.txt           # + test dependencies
├── LICENSE
└── README.md
```

## Getting Started

**Prerequisites:** Python 3.11 or newer.

```bash
# 1. Clone the repository
git clone https://github.com/Aiskillua/Fraud-detection-online-transactions-.git
cd Fraud-detection-online-transactions-

# 2. Create and activate a virtual environment
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Launch the dashboard
streamlit run app.py
```

The app opens at <http://localhost:8501>.

> **Note:** `scikit-learn` is pinned to `1.9.0` because the bundled model was serialized with that version. Pickled models are not guaranteed to load across versions.

## Usage

### Single transaction
Go to **Fraud Detection → Single Transaction**, enter the step, amount, and type, then click **Analyze Transaction**.

### Batch scoring
Go to **Fraud Detection → Batch Upload** and upload a CSV containing these columns:

```
step, amount, type_CASH_OUT, type_DEBIT, type_PAYMENT, type_TRANSFER
```

Try it with [`data/sample_transactions.csv`](data/sample_transactions.csv). Results (probability + prediction per row) can be downloaded as CSV.

### Live simulation
Go to **Live Simulation**, choose how many transactions to stream and the speed, and click **Start Live Stream**.

## Configuration

Key settings sit at the top of [`app.py`](app.py):

| Setting | Purpose |
|---|---|
| `MODEL_PATH` | Location of the model file (resolved relative to `app.py`) |
| `FEATURE_COLUMNS` | Model input columns, in training order |
| `MODEL_METRICS` | Metrics shown on the *Model Performance* page. **Update these if you retrain.** |

## Testing

```bash
pip install -r requirements-dev.txt
pytest -q
```

The smoke tests confirm the model loads and scores data, the app renders without errors, and the single-transaction flow works end to end. The same tests run automatically on GitHub Actions for Python 3.11 and 3.12.

## Limitations

Being upfront about what this project is and isn't:

- **Synthetic data.** PaySim is simulated; performance on real-world payment data is not guaranteed.
- **Overview page is a demo.** Its orders, customers, and fraud scores are randomly generated by `generate_demo_data()` and are **not** model output. The *Fraud Detection*, *Live Simulation*, and *Session History* pages use the real model.
- **Live Simulation uses random transactions**, not real traffic.
- **Class balance affects precision.** The evaluation set is ~14% fraud, whereas raw PaySim is ~0.13%. At real-world fraud rates, precision would be considerably lower for the same recall.
- **Metrics on the Performance page are stored values** in `app.py`, not recomputed at runtime.
- **Risk-factor breakdown is an approximation** (feature importance weighted by input magnitude), not an exact per-prediction explanation such as SHAP.
- **Security:** model files are loaded with `pickle`/`joblib`, which can execute code. Only load model files from sources you trust.

## Roadmap

- [ ] Add the training notebook / script for full reproducibility
- [ ] Per-prediction explanations with SHAP
- [ ] Precision-recall curve and threshold-tuning view
- [ ] Compute metrics at runtime from a held-out test file
- [ ] Dockerfile and one-click deployment (e.g. Streamlit Community Cloud)

## License

Distributed under the [MIT License](LICENSE).

---

<sub>Built by [@Aiskillua](https://github.com/Aiskillua) · Dataset: PaySim · Built with scikit-learn, Streamlit & Plotly</sub>
